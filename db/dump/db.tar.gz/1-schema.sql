CREATE DATABASE  IF NOT EXISTS `justicafacil`;

USE `justicafacil`;

DROP TABLE IF EXISTS `processos`;

CREATE TABLE processos (
    nrprocesso VARCHAR(255) NOT NULL,
    assunto VARCHAR(255) NOT NULL,
    vara VARCHAR(255) NOT NULL,
    parte_autora VARCHAR(255) NOT NULL,
    parte_re VARCHAR(255) NOT NULL,
    classe_processual VARCHAR(255) NOT NULL,
    advogado VARCHAR(255) NOT NULL,
    magistrado VARCHAR(255) NOT NULL,
    pro_improcedente VARCHAR(255) NOT NULL,
    teve_tutela VARCHAR(255) NOT NULL,
    PRIMARY KEY (nrprocesso)
);
